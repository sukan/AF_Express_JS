const User = function(pfirstName, plastName, pbDay, pid){
    this.firstName = pfirstName;
    this.lastName = plastName;
    this.bDay = pbDay;
    this.id = pid;

}

module.exports = User;