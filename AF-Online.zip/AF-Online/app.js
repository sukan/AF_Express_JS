const exp = require('express');
const bodyParser = require('body-parser');

//User.js
const userObject = require('./User');

const app = exp();

//create array
const userArr = [];

app.use(bodyParser.json());

//Fetch port
/*
const PORT = process.env.PORT || 3000
app.listen('/',() => console.info(`Server has been started ${PORT}`));
*/

app.listen(3000, err =>{
    if(err){
        console.error(err);
        return;
    }
    console.log('app listening to PORT 3000')
});


//POST Method
//add user to array

app.post('/add', function (req,res){
    const user = new userObject(req.body.fname, req.body.lname, new Date(req.body.BDay), Date.now());
    userArr.push(user);
    res.status('200').send({message : 'User added to the array', data : user});
})


//GET Method
//Get all the users from array

app.get('/all', function (req,res) {
    try{
        res.status('200').send({data : userArr});
    }catch(e){
        res.status('500').send({message: e});
    }
});

//GET method
//get user by id.

app.get('/userbyid/:id', function(req,res){

    try {
        const index = userArr.findIndex(x => x.id == req.params.id);
        if (index > -1) {
            res.status('200').send(userArr[index]);
        } else {
            res.status('404').send({message: 'Invalid ID'});
        }
    }catch (e){
       res.status('500').send({message:e});
    }

});

//Put method
//update user by id

app.put('/update/:id ', function (req,res) {
    const index = userArr.findIndex(instance => instance.id == req.params.id);
    userArr[index].firstName = req.body.fname;
    userArr[index].lastName = req.body.lname;
    userArr[index].bDay = req.body.BDay;

    res.status('200').send(userArr[index]);
});

//Another Update Method without functions
/*
app.put('/update/:id',(req,res)=>{
    const user = req.body;
    const index = userArr.findIndex(instance => instance.id === parseInt(req.params.id) );
    user.bDay = new Date(user.bDay);
    userArr[index] = user;
    res.status('200').send({data: userArr[index]})
});*/

//Delete method
//delete user

app.delete('/delete/:id', function (req,res){
    try{
        const index = userArr.findIndex(x => x.id == req.params.id);
        if(index > -1 ){
            const delUser = userArr.splice(index,1);
            res.status('200').send({message : 'user deleted from array', removedObject : delUser, data:userArr});
        }
        else {
            res.status('404').send({message : 'Invalid ID'});
        }
    }catch (e){
        res.status('500').send ({message : e});
    }
});








