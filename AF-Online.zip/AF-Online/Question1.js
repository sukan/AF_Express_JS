'use strict'
const bodyParser = require('body-parser')
const express = require('express')
const app = express()

app.use(bodyParser());
app.use(bodyParser.json());
app.use(express.static('public'));

//redirect index page
app.get('/',(req,res,next) => {
    res.sendFile('index.html')
});

const users = [];

//read users
app.get('/users', (req,res) => {
    res.json(users);
});

//find users
app.get('/users/:id', (req,res) => {
    const user = users.find(user => user.id === parseInt(req.params.id));
    res.json(user);
});

//create user
app.post('/users',(req,res)=>{
    const user=req.body;
    user.bday=new Date(user.bday);
    user.id=Date.now();
    users.push(user);
    res.json(user);
});

//update user id
app.put('/users/:id' , (req,res) => {
    const user = req.body;
    const index = users.findIndex(user => user.id === parseInt(req.params.id));
    user.bday = new Date(user.bday);
    users[index] = user;
    res.json(users[index]);
});

//delete user
app.delete('/users/:id' , (req,res) => {
    const user = req.body;
    const index = users.findIndex(user => user.id === parseInt(req.params.id));
    users.splice(index,1);
    res.sendStatus(200);
});

//fetch port
const PORT = process.env.PORT || 3000
app.listen(PORT, () => console.info(`server has started on ${PORT}`))
